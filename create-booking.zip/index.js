// index.js
const AWS = require('aws-sdk'); 
const dynamodb = new AWS.DynamoDB.DocumentClient();
const { v4: uuidv4 } = require('uuid'); // For generating unique IDs

exports.handler = async (event) => {
  try {
    // Parse the incoming event body
    const data = JSON.parse(event.body);
    const bookingId = uuidv4();

    const params = {
      TableName: 'Bookings',
      Item: {
        BookingID: bookingId,
        UserID: data.userId,
        ServiceID: data.serviceId,
        Date: data.date,
        TimeSlot: data.timeSlot,
        Status: 'Booked',
      },
    };

    // Insert the booking into DynamoDB
    await dynamodb.put(params).promise();

    return {
      statusCode: 201,
      body: JSON.stringify({ bookingId }),
    };
  } catch (error) {
    console.error('Error creating booking:', error);
    return {
      statusCode: 500,
      body: JSON.stringify({ error: 'Could not create booking' }),
    };
  }
};
